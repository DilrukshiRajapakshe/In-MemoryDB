create function orderTotal(qty int, unitPrice decimal)
  returns decimal
  BEGIN
    DECLARE total DECIMAL;
    SET total =  qty * unitPrice;
    return total;
  end;

